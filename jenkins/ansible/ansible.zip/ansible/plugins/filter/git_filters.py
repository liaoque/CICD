#!/usr/bin/python
# -*- coding: utf-8 -*-

import fnmatch
import grp
import os
import pwd
import re
import stat
import sys
import time

def pfilter(f, patterns=None, excludes=None, use_regex=False):
    '''filter using glob patterns'''
    if patterns is None and excludes is None:
        return True

    if use_regex:
        if patterns and excludes is None:
            for p in patterns:
                r = re.compile(p)
                if r.match(f):
                    return True

        elif patterns and excludes:
            for p in patterns:
                r = re.compile(p)
                if r.match(f):
                    for e in excludes:
                        r = re.compile(e)
                        if r.match(f):
                            return False
                    return True

    else:
        if patterns and excludes is None:
            for p in patterns:
                if fnmatch.fnmatch(f, p):
                    return True

        elif patterns and excludes:
            for p in patterns:
                if fnmatch.fnmatch(f, p):
                    for e in excludes:
                        if fnmatch.fnmatch(f, e):
                            return False
                    return True

    return False


class FilterModule(object):
    def filters(self):
        return {
            'git_filter': self.git_filter
            }
            
    @staticmethod
    def git_filter(files, patterns=None, excludes=None, use_regex=False):
        filelist = []
        for file in files:
            res = pfilter(file[u'path'], patterns, excludes, use_regex)
            if res:
                filelist.append(file)
        return filelist


